public class LineSuffixException extends Exception
{
    public LineSuffixException(String illegalSuffixMsg) {

        super(illegalSuffixMsg);
    }
}
