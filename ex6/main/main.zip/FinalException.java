public class FinalException extends Exception
{
    public FinalException(String assignmentToFinalVar) {

        super(assignmentToFinalVar);
    }
}
