public class IllegalLineException extends Exception
{
    public IllegalLineException(String illegal_line) {

        super(illegal_line);
    }
}
