public class IlegalCommentOrArrayException extends Exception {
    public IlegalCommentOrArrayException(String illegalCommentOrArrMsg) {
        super(illegalCommentOrArrMsg);
    }
}
