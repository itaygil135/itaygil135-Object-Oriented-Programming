public class ScopeException extends Exception
{
    public ScopeException() {

        super("this is Scope error. ");
    }
}
