public class AssignmentException extends Exception
{




    public AssignmentException(String msg) {
        super(msg);
    }

}
