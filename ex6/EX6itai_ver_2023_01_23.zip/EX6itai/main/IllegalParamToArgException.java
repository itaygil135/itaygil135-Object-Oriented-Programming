public class IllegalParamToArgException extends Exception
{
    public IllegalParamToArgException() {

        super("this is IllegalParamToArg error. ");
    }
}
