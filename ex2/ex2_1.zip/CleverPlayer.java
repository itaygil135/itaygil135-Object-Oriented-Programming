/*
class name: CleverPlayer
description: implement the logic for a clever player
 */
public class CleverPlayer implements Player {

    // the clever player fill in the cells column by column, starting from column 0
    public void playTurn(Board board, Mark mark) {
        for (int col = 0; col < board.getSize(); col++) {
            for (int row = 0; row < board.getSize(); row++)  {
                if(board.getMark(row, col) == Mark.BLANK)   {
                    board.putMark(mark, row, col);
                    return;
                }
            }
        }
    }
}