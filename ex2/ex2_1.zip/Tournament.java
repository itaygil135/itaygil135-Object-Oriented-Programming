import java.util.*;
public class Tournament {
// const definitons
private static final int ROUNDS = 0;
private static final int BOARDSIZE = 1;
private static final int WINLENGTH = 2;
private static final int RENDERER = 3;
private static final int PLAYERA = 4;
private static final int PLAYERB = 5;
private final int rounds;
private final Renderer renderer;
private final Player[] players;

/*
class name: Tournament
description:
param rounds: number of game rounds
param renderer:
param Player: list of players
 */
public Tournament(int rounds, Renderer renderer, Player[]players)     {
        this.rounds = rounds;
        this.renderer = renderer;
        this.players = new Player[]{players[0],players[1]};
    }

    /*
    class name: playTournament
    description:
    param size: board size
    param winStreak: number of games that considered as win
    param playerNames: list of players names
     */
public void playTournament(int size, int winStreak, String[] playerNames)     {
        int NumOfRounds = 0;
        int[] TableContest = new int[]{0,0,0};
        while(NumOfRounds < this.rounds)
        {
            Game gamee = new Game(this.players[NumOfRounds%2], this.players[(NumOfRounds+1)%2],size,
                    winStreak, this.renderer);
            switch(gamee.run())
            {
                case BLANK:
                    TableContest[2]++;
                    break;
                case X:
                    TableContest[NumOfRounds%2]++;
                    break;
                case O:
                    TableContest[(NumOfRounds+1)%2]++;
                    break;

            }
            NumOfRounds++;
        }
        System.out.println("######### Results #########");
        System.out.printf("Player 1, %s won: %d rounds%n",playerNames[0], TableContest[0]);
        System.out.printf("Player 2, %s won: %d rounds%n",playerNames[1], TableContest[1]);
        System.out.printf("Ties: %d",TableContest[2]);
    }

    /*
class name: main
description: game entry point
 */
public static void main(String[] args)     {
        PlayerFactory playerFactory = new PlayerFactory();
        Player playerA = playerFactory.buildPlayer(args[PLAYERA].toLowerCase());
        if(playerA == null){return;}
        Player playerB = playerFactory.buildPlayer(args[PLAYERB].toLowerCase());
        if(playerB == null){return;}
        Player[] PlayersArr = new Player[]{playerA,playerB};
        RendererFactory rendererFactory = new RendererFactory();
        Renderer RendererArg = rendererFactory.buildRenderer(args[RENDERER],
                                Integer.parseInt(args[BOARDSIZE]));
        Tournament tournament = new Tournament(Integer.parseInt(args[ROUNDS]),RendererArg, PlayersArr);
        String []playerNames = new String[]{args[PLAYERA],args[PLAYERB]};
        tournament.playTournament(Integer.parseInt(args[BOARDSIZE]),Integer.parseInt(args[WINLENGTH]),playerNames);
        //playTournament((int)args[1],(int)args[2],String[]{args[4],args[5]});

    }

}