
/**
 ** Enum wich represent the mark/sign that we paint on the board
 */

public enum Mark{BLANK, X, O};