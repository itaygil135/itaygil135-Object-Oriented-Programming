public class VoidRenderer implements Renderer
{
/**
   param: board - the board game
**/
        public void renderBoard(Board board){}
}