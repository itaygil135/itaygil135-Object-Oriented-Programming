/**
 interface for defining at "high" way each player and make their move by their own each stratagy
 **/
interface Player {
 /**
  * method that plays a singel turn
  * param: board - the board game
  * param: mark - mark the sign of this player at the position he chose at this turn
  **/
    void playTurn(Board board, Mark mark);
}