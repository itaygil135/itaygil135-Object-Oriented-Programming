
/*
class name: GenuisPlayer
description: implement the logic for a genuis player
 */
public class GeniusPlayer implements Player {
    public void playTurn(Board board, Mark mark)     {
        for(int row = 1; row < board.getSize(); row++)        {
            for(int col = 0; col < board.getSize(); col++) {
                if(board.getMark(row, col) == Mark.BLANK) {
                    board.putMark(mark, row, col);
                    return;
                }
            }
        }
    }
}