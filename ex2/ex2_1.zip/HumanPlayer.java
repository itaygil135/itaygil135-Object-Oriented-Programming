import java.util.*;

/*
class name: HumanPlayer
description: implement the logic for a human player
 */
public class HumanPlayer implements Player {
    private static final String USER_TYPE = "Player %s, type coordinated: ";
    private static final String ILIGEL_CORDINATES = "Invalid coordinates, type again: ";
    private Scanner UserInput;

    // constructor
    public HumanPlayer()     {
        UserInput = new Scanner(System.in);
    }

    // one turn of the player
    public void playTurn(Board board, Mark mark)    {
        String sign = (mark == Mark.X) ? "X" : "O";
        System.out.format(USER_TYPE, sign);
        while(true)        {
            int cordinates = UserInput.nextInt();
            int LeftCor = (cordinates / 10) ; //TODO check if - 1
            int RightCor = (cordinates % 10) ;//TODO check if - 1
            if(board.putMark(mark, LeftCor, RightCor)) {return;}
            System.out.print(ILIGEL_CORDINATES);
        }
    }
}
