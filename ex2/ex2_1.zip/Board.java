/*
class name: Board
description: generate a new board. board size might be an in parameter or a default size
 */
public class Board
{
    private static final int DEF_SIZE = 4;


    private final int BoardSize;
    private final Mark[][] board;


    // generate new board of a given size
    public Board(int size)
    {
        this.BoardSize = size;
        this.board = new Mark[size][size];
        for(int row = 0; row < size;row++)
        {
            for(int col = 0; col < size;col++)
            {
                this.board[row][col] = Mark.BLANK;
            }
        }
    }

    // genereate a new board of default size
    public Board()
    {
        this.BoardSize = DEF_SIZE;
        this.board = new Mark[DEF_SIZE][DEF_SIZE];
        for(int row = 0; row < DEF_SIZE;row++)
        {
            for(int col = 0; col < DEF_SIZE;col++)
            {
                this.board[row][col] = Mark.BLANK;
            }
        }
    }

    // return the size for the board
    public int getSize()
    {
        return this.BoardSize;
    }

    // return the board of the board instance
    public Mark[][] getBoard()
    {
        return this.board;
    }

    private boolean isInsideBounds(int row, int col)
    {
        return ((row >= 0) && (row < this.BoardSize) && (col >= 0) && (col < this.BoardSize));
    }


    // mark a given cell with the player sign
    public boolean putMark(Mark mark, int row, int col)
    {
        if(isInsideBounds(row,col) && (this.board[row][col] == Mark.BLANK))
        {
            this.board[row][col] = mark;
            return true;
        }
        return false;
    }

    // return the mark of af given cell
    public Mark getMark(int row, int col)
    {
        if(isInsideBounds(row,col))
        {
            return this.board[row][col];
        }
        return Mark.BLANK;
    }

}