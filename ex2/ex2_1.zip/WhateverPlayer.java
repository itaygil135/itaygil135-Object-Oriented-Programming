import java.util.*;
/*
class name: WhateverPlayer
description: implement the logic for a whatever player
 */
public class WhateverPlayer implements Player {
    private final Random rand = new Random();

    // the whatever player select a random cell and fill it
    public void playTurn(Board board, Mark mark)     {
        int LeftCor = rand.nextInt(board.getSize());
        int RightCor = rand.nextInt(board.getSize());
        while(true)         {
            if(board.putMark(mark, LeftCor, RightCor)){return;}
            LeftCor = rand.nextInt(board.getSize());
            RightCor = rand.nextInt(board.getSize());
        }
    }
}
