/*
class name: Game
description:
 */
public class Game {


 private static final int DEF_WIN_STREAK = 3;


 private final int winStreak;
 private final Board BoardGame;
 private Player[] PlayersGame;
 private Renderer RendererGame;
 private int NumOfUnemptyPlace;

 public Game(Player playerX, Player playerO, Renderer renderer)  {
     this.winStreak = DEF_WIN_STREAK;
     this.BoardGame = new Board();
     this.PlayersGame = new Player[]{playerX, playerO};
     this.RendererGame = renderer;
     this.NumOfUnemptyPlace = 0;

 }

 public Game(Player playerX, Player playerO, int size, int winStreak, Renderer renderer) {
      if((winStreak <= 1) || (winStreak > size))      {
          this.winStreak = size;
      }
      else {this.winStreak = winStreak;}

      this.BoardGame = new Board(size);
      this.PlayersGame = new Player[]{playerX, playerO};
      this.RendererGame = renderer;
      this.NumOfUnemptyPlace = 0;

 }
private void getLastSign(int[] cordinates,Mark[][] CurBoard,Mark[][] BeforeBoard,int length) {
    for(int r = 0; r < length;r++)    {
        for( int c = 0; c < length;c++)  {
            if(CurBoard[r][c] != BeforeBoard[r][c])  {
                cordinates[0] = r;
                cordinates[1] = c;
                return;
            }
        }
    }
}
 private Mark[][] assimentOfBoard(int length)  {
     Mark[][] back = new Mark[length][length];
     for(int r = 0; r < length;r++)      {
         for( int c = 0; c < length;c++)          {
            back[r][c] = BoardGame.getMark(r,c);
         }
     }
     return back;
 }
private boolean IsCurePlaeyrWonByRowOrCol(Mark sign) {
    int size = BoardGame.getSize();
    int RowStraight = 0;
    int ColStraight = 0;
    for (int row = 0; row < size; row++) {
        RowStraight = 0;
        for (int col = 0; col < size; col++) {
            if (BoardGame.getMark(row, col) == sign) {
                RowStraight++;
            } else {
                RowStraight = 0;
            }
            if (RowStraight == winStreak) {
                return true;
            }
        }
    }

    for (int col = 0; col < size; col++) {
        ColStraight = 0;

        for (int row = 0; row < size; row++) {
            if (BoardGame.getMark(row, col) == sign) {
                ColStraight++;
            } else {
                ColStraight = 0;
            }
            if (ColStraight == winStreak) {
                return true;
            }
        }
    }
   return false;
}



private boolean isCurePlaeyrWonByAlachson(Mark sign, Mark[][] Looah, int row, int col)
{
    int size = BoardGame.getSize();
    int AlachsonB = 1;
    int drow = row + 1;
    int dcol = col + 1;
    int UpRow = row - 1;
    int UpCol = col - 1;
    int AlachsonA = 1;
    int dShura = row - 1;
    int dAmuda = col + 1;
    int UpShura = row + 1;
    int UpAmuda = col - 1;

    while(dShura >= 0 && dAmuda < size)
    {
        if(Looah[dShura][dAmuda] != sign) {break;}
        AlachsonA++;
        dShura--;
        dAmuda++;
    }
    while (UpShura < size && UpAmuda >= 0)
    {
        if (Looah[UpShura][UpAmuda] != sign) {break;}
        AlachsonA++;
        UpShura++;
        UpAmuda--;
    }
    if(AlachsonA >= winStreak){return true;}

    while (drow < size && dcol < size)
    {
        if (Looah[drow][dcol] != sign) {break;}
        AlachsonB++;
        drow++;
        dcol++;
    }

    while (UpRow >= 0 && UpCol >= 0)
        {
            if (Looah[UpRow][UpCol] != sign) {break;}
            AlachsonB++;
            UpRow--;
            UpCol--;
        }
    return AlachsonB >= winStreak;
}



public int getWinStreak()
 {
  return this.winStreak;
 }


 public Mark run()
 {
    int[] CorPick = new int[]{-1, 9};
    Mark CurSign = Mark.X;
    int sizee = BoardGame.getSize();
    int SizeOnSize = sizee*sizee;
    while (NumOfUnemptyPlace < SizeOnSize)
    {
        if(NumOfUnemptyPlace%2 == 1){CurSign = Mark.O;}
        RendererGame.renderBoard(BoardGame);
        Mark[][] BoardGameBeforeMark = assimentOfBoard(sizee);
        PlayersGame[NumOfUnemptyPlace%2].playTurn(BoardGame,CurSign);
        getLastSign(CorPick,BoardGame.getBoard(),BoardGameBeforeMark,sizee);
        if(IsCurePlaeyrWonByRowOrCol(CurSign)){return CurSign;}
        if(isCurePlaeyrWonByAlachson(CurSign,BoardGame.getBoard(),CorPick[0],CorPick[1])){return CurSign;}
        CurSign = Mark.X;
        NumOfUnemptyPlace++;
     }
    return Mark.BLANK;
 }
}
