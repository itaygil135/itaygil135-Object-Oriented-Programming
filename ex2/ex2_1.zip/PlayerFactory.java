import java.util.*;
/*
class name: PlayerFactory
description: generate a new player instance of a different types
 */
public class PlayerFactory
{
    private static final String NO_SUCH_NAME = "Choose a player, and start again\n" +
            " The players: [human, clever, whatever, genius]";

    /**
     * param: type of the Player
     * return: Player instance
     **/
    public Player buildPlayer(String type)
    {
        switch(type)

        {
            case "genius":
                return new GeniusPlayer();

            case "clever":
                return new CleverPlayer();

            case "whatever":
                return new WhateverPlayer();

            case "human":
                return new HumanPlayer();

        }
    System.err.println(NO_SUCH_NAME);
    return null;
    }
}