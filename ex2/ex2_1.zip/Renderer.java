/**
   interface for a defining by general/high way the renderer
  **/
interface Renderer {
 /**
  * method which gets a board game as a param and choose the way to show or not show it to the screen
  * param: board - the game board
  **/
    void renderBoard(Board board);
}