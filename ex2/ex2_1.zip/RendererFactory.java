/*
class name: RendererFactory
description:
 */
public class RendererFactory
{
/**
 * param: type of the renderer
 * param: size the size of the board in case of console renderer
 * return: renderer instance
 **/
    public Renderer buildRenderer(String type, int size)     {
        switch(type)    {
                case "console":
                    return new ConsoleRenderer(size);
                case "none":
                    return new VoidRenderer();
            }
        return null;
    }
}