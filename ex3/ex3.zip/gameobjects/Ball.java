package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.GameManager;
import danogl.collisions.GameObjectCollection;
import danogl.gui.Sound;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import src.BrickerGameManager;

public class Ball extends GameObject {

    private final GameObjectCollection obj;
    private final BrickerGameManager game;
    private Sound collisionSound;
    private boolean CameraOnMe = false;
    private int collisionCount = 0;
    private static boolean extraPaddleOn = false;

    /**
     * Construct a new GameObject instance.
     *
     * @param topLeftCorner Position of the object, in window coordinates (pixels).
     *                      Note that (0,0) is the top-left corner of the window.
     * @param dimensions    Width and height in window coordinates.
     * @param renderable    The renderable representing the object. Can be null, in which case
     */
    public Ball(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                GameObjectCollection obj,BrickerGameManager gameManager, Sound collisionSound) {
        super(topLeftCorner, dimensions, renderable);
        this.obj = obj;
        this.game = gameManager;
        this.collisionSound = collisionSound;
        setTag("Ball");
    }

    public void setCollisionCount()
    {
        collisionCount++;
        if (collisionCount == 4)
            collisionCount = 0;

    }

    public int getCollisionCount()
    {
        return collisionCount;
    }
    public boolean isCameraOnMe() {
        return CameraOnMe;
    }

    public void turnCameraOnMe() {
        CameraOnMe = true;
    }

    public void ofCameraOnMe(){
        CameraOnMe = false;
    }

    public boolean isExtraPaddleOn(){return  extraPaddleOn;}
    public void changeExstraPaddle(){extraPaddleOn = true;}
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if (CameraOnMe)
        {
          collisionCount++;
          if(collisionCount == 4)
          {
              collisionCount = 0;
              this.game.setCamera(null);
              CameraOnMe = false;
          }

        }
        String type = other.getTag();
        switch (type){
            case "ExtraPaddle":
                other.setTag("ExtraPaddle1");
                break;
            case "ExtraPaddle1":
                other.setTag("ExtraPaddle2");
                break;
            case "ExtraPaddle2":
                this.obj.removeGameObject(other);
                extraPaddleOn = false;
                break;
        }
        Vector2 newVel = getVelocity().flipped(collision.getNormal());
        setVelocity(newVel);
        collisionSound.play();
    }
}
