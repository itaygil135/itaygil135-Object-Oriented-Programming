package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;

import java.awt.*;

public class NumericLifeCounter extends GameObject {
    private final TextRenderable textRenderable;
    private final Counter livesCounter;
    private final Vector2 topLeftCorner;
    private final Vector2 dimensions;
    private final GameObjectCollection gameObjectCollection;
    private int numOfLives;
    private int pointsOnScreen;
    private GameObject gameObject;


    public NumericLifeCounter(Counter livesCounter, Vector2 topLeftCorner, Vector2 dimensions,
                              GameObjectCollection gameObjectCollection) {
        super(topLeftCorner, dimensions, null);
        this.livesCounter = livesCounter;
        this.pointsOnScreen = livesCounter.value();
        this.topLeftCorner = topLeftCorner;
        this.dimensions = dimensions;
        this.gameObjectCollection = gameObjectCollection;
        this.numOfLives = livesCounter.value();
        this.textRenderable = new TextRenderable(String.valueOf(pointsOnScreen));
        this.textRenderable.setColor(Color.green);
        this.gameObject = new GameObject(topLeftCorner, dimensions, textRenderable);
        gameObjectCollection.addGameObject(gameObject, Layer.UI);
    }


    public void succidToGrab()
    {
        if(livesCounter.value() < 4)
        this.livesCounter.increment();
    }



    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
       if (livesCounter.value() < numOfLives ) {
            pointsOnScreen = livesCounter.value();
            textRenderable.setString(String.valueOf(pointsOnScreen));
            this.textRenderable.setColor(Color.green);
            gameObjectCollection.removeGameObject(gameObject, Layer.UI);
            gameObject = new GameObject(topLeftCorner, dimensions, textRenderable);
            gameObjectCollection.addGameObject(gameObject, Layer.UI);
            switch (String.valueOf(pointsOnScreen)) {
                case "4":
                    this.textRenderable.setColor(Color.green);
                    break;
                case "3":
                    this.textRenderable.setColor(Color.green);
                    break;
                case "2":
                    this.textRenderable.setColor(Color.yellow);
                    break;
                case "1":
                    this.textRenderable.setColor(Color.red);
                    break;
            }
        }
    }
}