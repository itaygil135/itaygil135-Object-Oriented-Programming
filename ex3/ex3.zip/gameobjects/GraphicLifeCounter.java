package src.gameobjects;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;

public class GraphicLifeCounter extends GameObject {

    private final Counter livesCounter;
    private final GameObjectCollection gameObjectsCollection;
    private final int numOfLives;

    private GameObject[] heartContainer;


    public GraphicLifeCounter(Vector2 widgetTopLeftCorner, Vector2 widgetDimensions, Counter livesCounter,
                              Renderable widgetRenderable,
                              GameObjectCollection gameObjectsCollection, int numOfLives) {
        super(widgetTopLeftCorner, widgetDimensions, null);
        this.livesCounter = livesCounter;
        this.gameObjectsCollection = gameObjectsCollection;
        this.numOfLives = numOfLives;
        this.heartContainer = new GameObject[numOfLives];
        for (int i = 0; i < numOfLives; i++) {
            GameObject heart = new GameObject(new Vector2(this.getTopLeftCorner().x()*i*2,
                    this.getTopLeftCorner().y()),
                    new Vector2(30
                    ,30),
                    widgetRenderable);
            this.heartContainer[i] = heart;
            gameObjectsCollection.addGameObject(heart,Layer.FOREGROUND);
        }

    }

    public void succsidToGrab()
    {
        if (livesCounter.value() < 4)
            livesCounter.increment();
    }
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        if(livesCounter.value() < numOfLives){
            gameObjectsCollection.removeGameObject(this.heartContainer[livesCounter.value()],Layer.FOREGROUND);
        }
    }


}