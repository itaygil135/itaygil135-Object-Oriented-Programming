package src.gameobjects;
import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.GameManager;
import danogl.collisions.GameObjectCollection;
import danogl.gui.Sound;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import src.BrickerGameManager;



public class WhiteBall extends Ball{

    public WhiteBall(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                     GameObjectCollection obj,BrickerGameManager gameManager, Sound collisionSound){
        super( topLeftCorner,  dimensions,  renderable,
                 obj, gameManager,collisionSound);
        setTag("WhiteBall");

    }
}
