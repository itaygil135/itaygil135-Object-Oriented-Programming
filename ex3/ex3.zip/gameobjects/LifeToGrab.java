package src.gameobjects;
import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import src.brick_strategies.CollisionStrategy;
import src.brick_strategies.MoreLifeStrategy;

public class LifeToGrab extends GameObject {

    private MoreLifeStrategy moreLifeStrategy;
    private GameObjectCollection obj;
    private BrickerGameManager game;

    private NumericLifeCounter numericLifeCounter;

    private  GraphicLifeCounter graphicLifeCounter;

    public LifeToGrab(Vector2 topLeftCorner, Vector2 dimensions, Renderable renderable,
                      GameObjectCollection obj, BrickerGameManager gameManager, NumericLifeCounter n,
                      GraphicLifeCounter g, MoreLifeStrategy moreLifeStrategy)
    {
        super(topLeftCorner,dimensions,renderable);
        this.obj =obj;
        this.game = gameManager;
        this.numericLifeCounter = n;
        this.graphicLifeCounter = g;
        this.moreLifeStrategy = moreLifeStrategy;
    }

    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        numericLifeCounter.succidToGrab();
        graphicLifeCounter.succsidToGrab();
        moreLifeStrategy.act(this);

    }
    @Override
    public boolean shouldCollideWith(GameObject other){
        return (other instanceof Paddle)&& !(other instanceof  ExtraPaddle);}
}
