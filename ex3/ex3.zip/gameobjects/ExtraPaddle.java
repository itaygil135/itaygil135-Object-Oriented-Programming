package src.gameobjects;

import danogl.gui.UserInputListener;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;

public class ExtraPaddle extends Paddle
{
    public ExtraPaddle(Vector2 topLeftCorner, Vector2 dimensions,
                       Renderable renderable, UserInputListener inputListener, Vector2 windowDimensions,
                       int minDistFromEdge)
    {
        super(topLeftCorner,dimensions,renderable,inputListener,windowDimensions,minDistFromEdge);
        setTag("ExtraPaddle");
    }
}
