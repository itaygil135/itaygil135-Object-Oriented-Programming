package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import src.gameobjects.Ball;
import src.gameobjects.WhiteBall;


public class ChangeCameraStrategy extends CollisionStrategy
{
     private final BrickerGameManager game;

    private final ImageReader imageReader;

    private final SoundReader soundReader;

    private final UserInputListener inputListener;

    private final WindowController windowController;

    private final Vector2 windowDimensions;

   public ChangeCameraStrategy(GameObjectCollection obj, BrickerGameManager gameManager,
                         ImageReader imageReader, SoundReader soundReader)
   {
        super(obj);
        this.game = gameManager;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
        this.inputListener = gameManager.getInputListener();
        this.windowController = gameManager.getWindowController();
        this.windowDimensions = this.windowController.getWindowDimensions();
   }

    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter counter) {
        super.onCollision(thisObj, otherObj, counter);
        if ((otherObj instanceof Ball) && !(otherObj instanceof WhiteBall)) {

        boolean doNothing = game.getBall().isCameraOnMe();
        if(!doNothing)
        {
            game.getBall().turnCameraOnMe();
            game.setCamera(new Camera(game.getBall(), //object to follow
                            Vector2.ZERO, //follow the center of the object
                            windowController.getWindowDimensions().mult(1.2f), //widen the frame a bit
                            windowController.getWindowDimensions() //share the window dimensions
                            )
            );
            game.getBall().turnCameraOnMe();
        }
    }

    }
}
