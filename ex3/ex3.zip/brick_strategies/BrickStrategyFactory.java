package src.brick_strategies;
import java.util.Random;
import danogl.collisions.GameObjectCollection;
import danogl.gui.*;
import danogl.util.Vector2;
import  src.BrickerGameManager;
import danogl.collisions.*;
import src.gameobjects.*;
import danogl.GameManager;
import danogl.GameObject;

/**
 * Factory class for creating Collision strategies.
 */
public class BrickStrategyFactory {

    private final Random rand = new Random();

    private final GameObjectCollection obj;
    private final BrickerGameManager gameManager;
    private final ImageReader imageReader;
    private final SoundReader soundReader;

    private static final int NUM_STRATEGIES = 6;


    /**
     * Constructor.
     * @param gameObjectCollection  global game object collection
     * @param gameManager GameManager instance that manages this game.
     * @param imageReader an ImageReader instance for reading images from files for rendering of objects.
     * @param soundReader a SoundReader instance for reading soundclips from files for rendering event sounds.
     * @param inputListener an InputListener instance for reading user input.
     * @param windowController controls visual rendering of the game window and object renderables.
     * @param windowDimensions pixel dimensions for game window height x width,
     * can be null to indicate a full-screen window whose size in pixels is the main screen's resolution
     */
    public BrickStrategyFactory(GameObjectCollection obj, BrickerGameManager gameManager,
                                ImageReader imageReader, SoundReader soundReader)
    {
        this.obj = obj;
        this.gameManager = gameManager;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
    }


    /**
     * method randomly selects between 5 strategies and returns one CollisionStrategy object which is a
     * RemoveBrickStrategy decorated by one of the decorator strategies,
     * or decorated by two randomly selected strategies,
     * or decorated by one of the decorator strategies and a pair of
     * additional two decorator strategies.
     * @return CollisionStrategy randomly selected
     */
    public CollisionStrategy getStrategy()
    {
        int randInt = rand.nextInt(NUM_STRATEGIES);
        if (randInt==0){
            return new CollisionStrategy(this.obj);
        }
        else if(randInt==1){
            return new MoreBallCollisionStrategy(this.obj,this.gameManager,this.imageReader,
                    this.soundReader);
        }
        else if (randInt==2){
            return new MorePaddleStrategy(this.obj,this.gameManager,this.imageReader,
                    this.soundReader);
        }
        else if (randInt==3){
            return new ChangeCameraStrategy(this.obj,this.gameManager,this.imageReader,
                    this.soundReader);
        }
        else if (randInt==4){
            return new MoreLifeStrategy(this.obj,this.gameManager,this.imageReader,
                    this.soundReader);
        }
        else {
            return new MoreLifeStrategy(this.obj,this.gameManager,this.imageReader,
                    this.soundReader);
        }
    }


}
