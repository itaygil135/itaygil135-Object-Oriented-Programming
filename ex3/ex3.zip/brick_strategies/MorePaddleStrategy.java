package src.brick_strategies;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import  src.gameobjects.Ball;
import src.gameobjects.ExtraPaddle;
import src.gameobjects.Paddle;

public class MorePaddleStrategy extends CollisionStrategy
{
    private final BrickerGameManager game;

    private final ImageReader imageReader;

    private final SoundReader soundReader;

    private final UserInputListener inputListener;

    private final WindowController windowController;

    private final Vector2 windowDimensions;

    public MorePaddleStrategy(GameObjectCollection obj, BrickerGameManager gameManager,
                                     ImageReader imageReader, SoundReader soundReader){
        super(obj);
        this.game = gameManager;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
        this.inputListener = gameManager.getInputListener();
        this.windowController = gameManager.getWindowController();
        this.windowDimensions = this.windowController.getWindowDimensions();
    }

    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter counter) {
        super.onCollision(thisObj, otherObj, counter);
        boolean doNothing = true;
        if (otherObj instanceof Ball) {
            Ball obj = (Ball) otherObj;
            doNothing = obj.isExtraPaddleOn();
            obj.changeExstraPaddle();
        }
        if(!doNothing)
        {

            Renderable extraPaddleImage =
                    imageReader.readImage("assets/paddle.png", false);
            ExtraPaddle exstraUserPaddle = new ExtraPaddle(
                    Vector2.ZERO,
                    new Vector2(this.game.getPaddleWidth(),this.game.getPaddleHeight()),
                    extraPaddleImage,
                    inputListener, windowDimensions,this.game.getMinDistFromEdge());

            exstraUserPaddle.setCenter(new Vector2(windowDimensions.x() / 2, windowDimensions.y()/2));
            GetGameObject().addGameObject(exstraUserPaddle);
        }
    }
}
