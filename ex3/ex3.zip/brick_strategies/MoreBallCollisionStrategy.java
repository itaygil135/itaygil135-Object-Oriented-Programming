package src.brick_strategies;
import src.gameobjects.*;
import danogl.GameObject;
        import danogl.collisions.Collision;
        import danogl.collisions.GameObjectCollection;
import danogl.gui.*;
import danogl.gui.rendering.Renderable;
        import danogl.util.Counter;
        import danogl.util.Vector2;
import src.BrickerGameManager;
import src.gameobjects.Ball;

import java.util.Random;


public class MoreBallCollisionStrategy extends CollisionStrategy
{
    private static final float PUCK_SPEED = 300;
    private final BrickerGameManager game;
    private final ImageReader imageReader;
    private final SoundReader soundReader;

    public MoreBallCollisionStrategy(GameObjectCollection obj, BrickerGameManager gameManager,
                                     ImageReader imageReader, SoundReader soundReader){
        super(obj);
        this.game = gameManager;
        this.imageReader = imageReader;
        this.soundReader = soundReader;

    }

    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter counter){
        super.onCollision(thisObj,otherObj,counter);
        Renderable packImage =
                imageReader.readImage("assets/mockBall.png",true);
        Sound collisionSound = soundReader.readSound("assets/blop.wav");
        Vector2 puckDimensions = new Vector2(thisObj.getDimensions().x()/3,thisObj.getDimensions().y());
        WhiteBall[] puck = new WhiteBall[3];
        for(int i = 0;i < 3;i++)
        {
            puck[i] = new WhiteBall(thisObj.getCenter(), puckDimensions, packImage,GetGameObject(),
                    this.game, collisionSound);
            float puckVelX = PUCK_SPEED;
            float puckVelY = PUCK_SPEED;
            Random rand = new Random();
            if (rand.nextBoolean())
                puckVelX *= -1;
            if (rand.nextBoolean())
                puckVelY *= -1;
            puck[i].setVelocity(new Vector2(puckVelX, puckVelY));
            GetGameObject().addGameObject(puck[i]);
        }




    }
}