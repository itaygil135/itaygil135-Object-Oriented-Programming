package src.brick_strategies;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.TextRenderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.BrickerGameManager;
import src.gameobjects.LifeToGrab;


public class MoreLifeStrategy extends CollisionStrategy
{
    private final BrickerGameManager game;

    private final ImageReader imageReader;

    private final SoundReader soundReader;

    private final UserInputListener inputListener;

    private final WindowController windowController;

    private final Vector2 windowDimensions;


    public MoreLifeStrategy(GameObjectCollection obj, BrickerGameManager gameManager,
                            ImageReader imageReader, SoundReader soundReader)
    {
        super(obj);
        this.game = gameManager;
        this.imageReader = imageReader;
        this.soundReader = soundReader;
        this.inputListener = gameManager.getInputListener();
        this.windowController = gameManager.getWindowController();
        this.windowDimensions = this.windowController.getWindowDimensions();
    }

    public void act(GameObject a)
    {
        GetGameObject().removeGameObject(a);
    }
    @Override
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter counter) {
        super.onCollision(thisObj, otherObj, counter);
        LifeToGrab heart = new LifeToGrab(new Vector2(thisObj.getCenter().x() - 15 ,thisObj.getCenter().y()),
                new Vector2(30,30),imageReader.readImage("assets/heart.png",true),
                this.GetGameObject(),game,game.getNumericLifeCounter(),game.getGraphicLifeCounter(),this);
                this.GetGameObject().addGameObject(heart);
                heart.setVelocity(new Vector2(0,100));


    }
}
