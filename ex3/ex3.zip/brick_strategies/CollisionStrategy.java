package src.brick_strategies;
import src.gameobjects.*;
import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.util.Counter;

public class CollisionStrategy {

    private final GameObjectCollection gameObjects;

    public CollisionStrategy(GameObjectCollection gameObjectCollection){
        this.gameObjects = gameObjectCollection;
    }

    public GameObjectCollection GetGameObject()
    {
        return this.gameObjects;
    }
    public void onCollision(GameObject thisObj, GameObject otherObj, Counter counter){
        gameObjects.removeGameObject(thisObj);
        counter.decrement();
    }

}