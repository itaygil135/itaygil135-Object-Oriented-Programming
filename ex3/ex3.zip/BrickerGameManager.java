package src;
import  src.gameobjects.*;
import src.brick_strategies.BrickStrategyFactory;
import  src.brick_strategies.*;
import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.*;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Counter;
import danogl.util.Vector2;
import src.gameobjects.Ball;
import src.gameobjects.Paddle;
import danogl.collisions.GameObjectCollection;
import src.gameobjects.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Random;


public class BrickerGameManager extends GameManager {
    private static final int BORDER_WIDTH = 10;
    private static final int PADDLE_HEIGHT = 20;
    private static final int PADDLE_WIDTH = 100;
    private static final int BALL_RADIUS = 35;
    private static final float BALL_SPEED = 350;
    private static final Renderable BORDER_RENDERABLE =
            new RectangleRenderable(new Color(80, 140, 250));
    private static final int ROWS_NUM = 8;
    private static final int COLS_NUM = 7;
    private static final int BRICK_WIDTH = 85;
    private static final int BRICK_HEIGHT = 20;

    private NumericLifeCounter numericLifeCounter;

    private GraphicLifeCounter graphicLifeCounter;
    private Ball ball;
    private Vector2 windowDimensions;
    private WindowController windowController;
    private Counter brickCounter;
    private final int minDistFromEdge = 5;
    private Counter lifeCounter;
    private final int numOfLives = 3;
    private UserInputListener inputListener;


    public NumericLifeCounter getNumericLifeCounter() {
        return numericLifeCounter;
    }

    public GraphicLifeCounter getGraphicLifeCounter() {
        return graphicLifeCounter;
    }

    public WindowController getWindowController() {
        return windowController;
    }

    public UserInputListener getInputListener() {
        return inputListener;
    }

    public static int getPaddleWidth() {
        return PADDLE_WIDTH;
    }

    public int getNumOfLives() {
        return numOfLives;
    }

    public static int getPaddleHeight() {
        return PADDLE_HEIGHT;
    }

    public int getMinDistFromEdge() {
        return minDistFromEdge;
    }

    public static int getBrickWidth() {
        return BRICK_WIDTH;
    }

    public static int getBrickHeight() {
        return BRICK_HEIGHT;
    }

    public static int getBorderWidth() {
        return BORDER_WIDTH;
    }

    public static int getBallRadius() {
        return BALL_RADIUS;
    }

    public Counter getLifeCounter() {
        return lifeCounter;
    }

    public static float getBallSpeed() {
        return BALL_SPEED;
    }

    public Counter getBrickCounter() {
        return brickCounter;
    }

    public static int getRowsNum() {
        return ROWS_NUM;
    }

    public static int getColsNum() {
        return COLS_NUM;
    }

    public Ball getBall() {
        return ball;
    }



    public BrickerGameManager(String windowTitle, Vector2 windowDimensions) {
        super(windowTitle, windowDimensions);
    }

    @Override
    public void initializeGame(ImageReader imageReader,
                               SoundReader soundReader,
                               UserInputListener inputListener,
                               WindowController windowController) {
        this.brickCounter = new Counter(56);
        this.lifeCounter = new Counter(3);
        this.windowController = windowController;
        this.inputListener = inputListener;
        //initialization
        super.initializeGame(imageReader, soundReader, inputListener, windowController);
        windowDimensions = windowController.getWindowDimensions();

        BrickStrategyFactory brickstrategyfactory = new BrickStrategyFactory(gameObjects(),
                this,imageReader,
                soundReader);

        //create ball
        createBall(imageReader, soundReader, windowController);


        //create paddles
        Renderable paddleImage = imageReader.readImage(
                "assets/paddle.png", false);
        createUserPaddle(paddleImage, inputListener, windowDimensions);
//        createAIPaddle(windowDimensions, paddleImage);

        //create borders
        createBorders(windowDimensions);

        numericLifeCounter = new NumericLifeCounter(lifeCounter, new Vector2(120,
                windowDimensions.y() - 60), new Vector2(30, 30), gameObjects());
        gameObjects().addGameObject(numericLifeCounter, Layer.UI);

        Renderable lifeImage =
                imageReader.readImage("assets/heart.png", true);
        GraphicLifeCounter graphicLifeCounter = new GraphicLifeCounter(new Vector2(20,
                windowDimensions.y() - 50), new Vector2(30, 30), lifeCounter, lifeImage, gameObjects(),
                numOfLives);
        gameObjects().addGameObject(graphicLifeCounter, Layer.UI);
        createBackground(imageReader, windowDimensions);


        Renderable brickImage =
                imageReader.readImage("assets/brick.png", true);
        CollisionStrategy collisionStrategy;
        for (int i = 0; i < ROWS_NUM; i++) {
            for (int j = 0; j < COLS_NUM; j++) {
                collisionStrategy = brickstrategyfactory.getStrategy();
                Brick new_brick = new Brick(new Vector2(50 + i * BRICK_WIDTH, 50 + j * BRICK_HEIGHT),
                        new Vector2(BRICK_WIDTH,
                                BRICK_HEIGHT), brickImage
                        , collisionStrategy, brickCounter);
                gameObjects().addGameObject(new_brick);
            }
        }

    }

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        checkForGameEnd();
    }

    private void checkForGameEnd() {
        double ballHeight = ball.getCenter().y();
        String prompt = "";
        if (ballHeight > windowDimensions.y()) {
            this.lifeCounter.decrement();
            ball.setCenter(windowDimensions.mult(0.5f));
            float ballVelX = BALL_SPEED;
            float ballVelY = BALL_SPEED;
            Random rand = new Random();
            if (rand.nextBoolean())
                ballVelX *= -1;
            if (rand.nextBoolean())
                ballVelY *= -1;
            ball.setVelocity(new Vector2(ballVelX, ballVelY));

        }
        if ((ballHeight < windowDimensions.y() && ballHeight > 0 && this.brickCounter.value() == 0) ||
                inputListener.isKeyPressed(KeyEvent.VK_W)) {
            //we win
            prompt = "You win!";
        }
        if (ballHeight > windowDimensions.y() && this.lifeCounter.value() == 0) {
            //we lost
            prompt = "You Lose!";
        }
        if (!prompt.isEmpty()) {
            prompt += " Play again?";
            if (windowController.openYesNoDialog(prompt))
                windowController.resetGame();
            else
                windowController.closeWindow();
        }
    }

    private void createBackground(ImageReader imageReader, Vector2 windowDimensions) {
        Renderable renderable = imageReader.readImage("assets/DARK_BG2_small.jpeg", false);
        GameObject backGround = new GameObject(new Vector2(0, 0), windowDimensions, renderable);
        backGround.setCoordinateSpace(backGround.getCoordinateSpace().CAMERA_COORDINATES);
        gameObjects().addGameObject(backGround, Layer.BACKGROUND);
    }

    private void createBall(ImageReader imageReader, SoundReader soundReader, WindowController windowController) {
        Renderable ballImage =
                imageReader.readImage("assets/ball.png", true);
        Sound collisionSound = soundReader.readSound("assets/blop.wav");
        ball = new Ball(
                Vector2.ZERO, new Vector2(BALL_RADIUS, BALL_RADIUS), ballImage,gameObjects(),
                this, collisionSound);

        Vector2 windowDimensions = windowController.getWindowDimensions();
        ball.setCenter(windowDimensions.mult(0.5f));
        gameObjects().addGameObject(ball);

        float ballVelX = BALL_SPEED;
        float ballVelY = BALL_SPEED;
        Random rand = new Random();
        if (rand.nextBoolean())
            ballVelX *= -1;
        if (rand.nextBoolean())
            ballVelY *= -1;
        ball.setVelocity(new Vector2(ballVelX, ballVelY));
    }

    private void createUserPaddle(Renderable paddleImage, UserInputListener inputListener, Vector2 windowDimensions) {
        GameObject userPaddle = new Paddle(
                Vector2.ZERO,
                new Vector2(PADDLE_WIDTH, PADDLE_HEIGHT),
                paddleImage,
                inputListener, windowDimensions, minDistFromEdge);

        userPaddle.setCenter(
                new Vector2(windowDimensions.x() / 2, (int) windowDimensions.y() - 30));
        gameObjects().addGameObject(userPaddle);
    }

    private void createBorders(Vector2 windowDimensions) {
        gameObjects().addGameObject(
                new GameObject(
                        Vector2.ZERO,
                        new Vector2(BORDER_WIDTH, windowDimensions.y()),
                        BORDER_RENDERABLE)
        );
        gameObjects().addGameObject(
                new GameObject(
                        new Vector2(windowDimensions.x() - BORDER_WIDTH, 0),
                        new Vector2(BORDER_WIDTH, windowDimensions.y()),
                        BORDER_RENDERABLE)
        );
        gameObjects().addGameObject(
                new GameObject(Vector2.ZERO,
                        new Vector2(windowDimensions.x(), BORDER_WIDTH),
                        BORDER_RENDERABLE)
        );
    }

    public static void main(String[] args) {
        new BrickerGameManager(
                "Bouncing src.gameobjects.Ball",
                new Vector2(800, 600)).run();
    }
}
