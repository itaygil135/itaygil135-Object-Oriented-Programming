package image;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A package-private class of the package image.
 * @author Dan Nirel
 */
class subImageIterator<T> implements Iterable<T> {
    private final Image img;
    private final int smallImageSize;

    public subImageIterator(
            Image img, int smallImageSize) {
        this.img = img;
        this.smallImageSize = smallImageSize;
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            int rowIndex = 0, colIndex = 0;


            @Override
            public boolean hasNext() {
                return rowIndex < img.getHeight();
            }

            @Override
            @SuppressWarnings("unchecked")
            public T next() {
                if (!hasNext())
                    throw new NoSuchElementException();
                var next = new SubIm(colIndex, rowIndex, smallImageSize, img);
//                var next = new Color[smallImageSize][smallImageSize];
//                for (int i = 0; i < smallImageSize; i++) {
//                    for (int j = 0; j < smallImageSize; j++) {
//                        next[i][j] = img.getPixel(i + rowIndex, j + colIndex);
//                    }
//                }
                colIndex += smallImageSize;
                if (colIndex >= img.getWidth()) {
                    colIndex = 0;
                    rowIndex += smallImageSize;
                }
                return (T) next;
            }
        };
    }
}
