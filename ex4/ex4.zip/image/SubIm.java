package image;

import java.awt.*;

public class SubIm implements Image
{
    private int xInd;
    private int yInd;

    private int size;
    private final Image image;

    private Color[][] subImage;

    public SubIm(int x,int y,int length,Image im)
    {
        xInd = x;
        yInd = y;
        size = length;
        image = im;
        subImage = new Color[size][size];
        for(int i = 0; i< size;i++)
            for (int j = 0;j < size;j++)
            {
                subImage[i][j] = image.getPixel(xInd +i,yInd + j);
            }
    }

    @Override
    public int getWidth() {
        return size;
    }

    @Override
    public int getHeight() {
        return size;
    }

    @Override
    public Color getPixel(int x, int y) {
        return subImage[y][x]; //if invalid indices, let the array throw the exception
    }

}
