package image;


import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * A package-private class of the package image.
 * @author Dan Nirel
 */
class FileImage implements Image {
    private static final Color DEFAULT_COLOR = Color.WHITE;

    private final Color[][] pixelArray;


    public FileImage(String filename) throws IOException {
        java.awt.image.BufferedImage im = ImageIO.read(new File(filename));
        int origWidth = im.getWidth(), origHeight = im.getHeight();
        //im.getRGB(x, y)); getter for access to a specific RGB rates


        int newWidth = (int)Math.pow(2, Math.ceil(Math.log(origWidth)/Math.log(2)));
        int newHeight = (int)Math.pow(2, Math.ceil(Math.log(origHeight)/Math.log(2)));

        pixelArray = new Color[newHeight][newWidth];

        //add your code here
        int widthRep = (newWidth-origWidth)/2;
        int heightRep = (newHeight-origHeight)/2;
        for (int i = 0; i< newWidth;i++)
            for(int j = 0; j < newHeight;j++)
            {
                if((i<widthRep)||(i>=origWidth+widthRep)||(j<heightRep)||(j>=origHeight+heightRep))
                {
                    pixelArray[i][j] = DEFAULT_COLOR;
                }
                else
                {
                    pixelArray[i][j] = new Color(im.getRGB(i-widthRep, j-heightRep));
                }
            }



    }


    @Override
    public int getWidth() {
        return pixelArray[0].length;
    }

    @Override
    public int getHeight() {
        return pixelArray.length;
    }

    @Override
    public Color getPixel(int x, int y) {
        return pixelArray[y][x]; //if invalid indices, let the array throw the exception
    }

}
