package ascii_art;
import java.util.*;
import java.util.stream.Stream;
import ascii_art.img_to_char.BrightnessImgCharMatcher;
import ascii_output.AsciiOutput;
import ascii_output.ConsoleAsciiOutput;
import ascii_output.HtmlAsciiOutput;
import image.Image;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;



public class Shell
{
    private static final int MIN_PIXELS_PER_CHAR = 2;
 private static final int INITIAL_CHARS_IN_ROW = 64;
 private final int minCharsInRow;
 private final int maxCharsInRow;
 private int charsInRow;
 private final Set<Character> charSet = new HashSet<>();
 private static final String FONT = "Courier New";
 private static final String OUTPUT_FILE = "out.html";
 private final BrightnessImgCharMatcher charMatcher;
 private final AsciiOutput htmlOutput;
 private AsciiOutput output;
 private final AsciiOutput consoleOutput;
 private static final String INITIAL_SET = "0-9";


     public Shell(Image img){
     this.minCharsInRow = Math.max(1, img.getWidth()/img.getHeight());
     this.maxCharsInRow = img.getWidth() / MIN_PIXELS_PER_CHAR;
     this.charsInRow = Math.max(Math.min(INITIAL_CHARS_IN_ROW, maxCharsInRow), minCharsInRow);
     this.charMatcher = new BrightnessImgCharMatcher(img, FONT);
     this.htmlOutput = new HtmlAsciiOutput(OUTPUT_FILE, FONT);
     this.consoleOutput = new ConsoleAsciiOutput();
     try
         {
             addition(INITIAL_SET);
         }
     catch (Exception doNotCare){}
     this.output = htmlOutput;


     }
     public void run() throws Exception {
         Scanner scanner = new Scanner(System.in);
         System.out.print(">>> ");
         String cmd = scanner.next().trim();
         while (!cmd.equalsIgnoreCase("exit"))
         {
             try {
                 switch (cmd) {
                     case "chars": {
                         for (char item : charSet) {
                             System.out.print(item);
                             System.out.print(" ");
                         }
                         System.out.println();
                         break;
                     }
                     case "add": {
                         addition(scanner.nextLine().trim());
                         break;
                     }
                     case "remove": {
                         delete(scanner.nextLine().trim());
                         break;
                     }
                     case "res": {
                         resolutionChange(scanner.nextLine().trim());
                         break;
                     }
                     case "render": {
                         render(scanner.nextLine().trim());
                         break;
                     }
                     case "console": {
                         this.output = consoleOutput;
                         break;
                     }
                 }
             }
             catch (Exception general){general.printStackTrace();}
             System.out.print("<<< ");
             cmd = scanner.next().trim();
         }
     }

    private void addition(String type) throws Exception
    {

        char[] firstAndLast = checkFirstLast(type);
        if(firstAndLast == null)
        {
            throw new Exception("Did not add due to incorrect format");
        }
        int end;
        int beginning;
        if(firstAndLast[0] > firstAndLast[1])
        {
            end = firstAndLast[0] + 1;
            beginning = firstAndLast[1];
        }
        else{
            beginning = firstAndLast[0];
            end = firstAndLast[1] + 1;
        }
        while (beginning != end)
        {
            if (!charSet.contains((char)beginning))
            {
                charSet.add((char)beginning);
            }
            beginning++;
        }
    }

    private void delete(String type) throws Exception
    {
        char[] firstAndLast = checkFirstLast(type);
        if(firstAndLast == null)
        {
            throw new Exception("Did not add due to incorrect format");
        }
        int end;
        int beginning;
        if(firstAndLast[0] > firstAndLast[1])
        {
            end = firstAndLast[0] + 1;
            beginning = firstAndLast[1];
        }
        else{
            beginning = firstAndLast[0];
            end = firstAndLast[1] + 1;
        }
        while (beginning != end)
        {
            if (charSet.contains((char)beginning))
            {
                charSet.remove((char)beginning);
            }
            beginning++;
        }
    }

    private void resolutionChange(String type) throws Exception
    {
        if (type.equals("up"))
        {updateRes(charsInRow*2,maxCharsInRow,charsInRow*2);}
        else if (type.equals("down"))
        {updateRes(minCharsInRow,charsInRow/2,charsInRow/2);}
        else
        {  throw new Exception("Did not executed due to incorrect command\n");}

    }

    private void render(String arg) throws Exception
    {
        Character[] array = charSet.toArray(new Character[0]);
        char[][] charsToOut = charMatcher.chooseChars(charsInRow, array);
        output.output(charsToOut);
        this.output = htmlOutput;
        }


    private void updateRes(int a, int b, int c)
    {
        if(a<=b)
        {
            this.charsInRow = c;
            System.out.println("Width set to "+ c);
        }
        else
        {
            System.out.println("Did not change due to exceeding boundaries");
        }
    }

    private static char[] checkFirstLast(String arg)
    {
        char[] back;
        String[] range = arg.split("-");
        if (range.length == 2 && range[0].length() == 1 && range[1].length() == 1)
        {
            back = new char[]{range[0].charAt(0), range[1].charAt(0)};
        }
        else if (arg.length() == 1)
        {
            char charToAdd = arg.charAt(0);
            back = new char[]{charToAdd, charToAdd};
        }
        else if (arg.equals("all"))
        {
            back = new char[]{' ', '~'};
        }
        else if(arg.equals("space"))
        {
            back = new char[]{' ', ' '};
        }
        else
        {back = null;}
        return back;
    }



}
