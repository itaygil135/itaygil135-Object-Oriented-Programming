package ascii_art.img_to_char;
import image.Image;

import java.util.Arrays;
import java.util.HashMap;
import java.awt.*;

public class BrightnessImgCharMatcher
{
    private final HashMap<Character, Float> bright_dict = new HashMap<Character, Float>();

    private final static int NUM_PIXELS_IN_ROW = 16;

    private final Image img;
    private final String font;




    public BrightnessImgCharMatcher(Image img, String font)
    {
        this.img = img;
        this.font = font;
    }

    public char[][] chooseChars(int numCharsInRow, Character[] charSet)
    {
        for (char item : charSet)
        {
            if(!bright_dict.containsKey((item)))
            {
                firstBrightCalc(item,NUM_PIXELS_IN_ROW, CharRenderer.getImg(item, NUM_PIXELS_IN_ROW, this.font));
            }
        }

        int row = 0;
        int col = 0;
        int sizeOfSubImage = img.getWidth()/numCharsInRow;
        int numRows = img.getHeight()/sizeOfSubImage;
        int numCols = img.getWidth()/sizeOfSubImage;
        char[][] asciiPicture = new char[numRows][numCols];


        for(Image sub: img.subImageIterate(sizeOfSubImage))
        {
            asciiPicture[row][col] = correctChar(linearStretch(),imageBrightness(sub));
            col++;
            if(col == numCols)
            {
                row++;
                col = 0;
            }
        }
        return asciiPicture;
    }

    public void firstBrightCalc(char item,int size,boolean[][] table)
    {
        int trueAmount = 0;
        for(int i = 0; i < size;i++)
        {
            for (int j = 0; j < size; j++)
            {
                if (table[i][j])
                    trueAmount++;
            }
        }
        bright_dict.put(item, ((float) trueAmount) / (size * size));
    }

    public HashMap<Character,Float> linearStretch()
    {
        float maxValue = 0;
        float minValue = 1.0F;
        for (float item : bright_dict.values()) {
            if (minValue > item)
                minValue = item;
            if (maxValue < item)
                maxValue = item;
        }
        HashMap<Character,Float> afterStretch = new HashMap<Character,Float>();
        for (char item : bright_dict.keySet())
        {
            afterStretch.put(item,(bright_dict.get(item)-minValue)/(maxValue - minValue));
        }
        return afterStretch;
    }


    public float imageBrightness(Image subImage)
    {
        float grayPixel;
        float sum = 0;
        float numOfPixels = 0;
        for (Color color : subImage.pixels())
        {
             grayPixel = color.getRed() * 0.2126F + color.getGreen() * 0.7152F
                     + color.getBlue() * 0.0722F;
             sum = sum + grayPixel;
             numOfPixels++;
        }

        return sum / (numOfPixels*255F);
    }

    public char correctChar(HashMap<Character,Float> optionalChar,float imageBright)
    {
        char cur = 's';
        float gap = 3.0F;

        for(char item:optionalChar.keySet())
        {
            if(Math.abs(optionalChar.get(item)-imageBright) < gap)
            {
                gap = Math.abs(optionalChar.get(item)-imageBright);
                cur = item;
            }
        }

        return cur;
    }
}
